# Core public classes
from .boolean_function import (
    BooleanFunction, 
    display_truth_table,
    get_layer_structure_from_canalized_outputs
)
from .boolean_network import (
    BooleanNetwork, 
    get_entropy_of_basin_size_distribution
)
from .wiring_diagram import WiringDiagram

# Canonical public generators
from .generate import (
    random_function,
    random_NCF,
    random_k_canalizing_function,
    random_wiring_diagram,
    random_network,
    random_null_model,
)

from .utils import (
    bin2dec,
    dec2bin,
    get_left_side_of_truth_table,
    hamming_weight_to_ncf_layer_structure,
    get_shannon_entropy,
)

from .modularity import (
    compress_trajectories,
    product_of_trajectories,
    plot_trajectory,
)

from .bio_models import get_bio_models_from_repository

from .utils_multistate import (
    mix2dec, dec2mix,
    mix2bin, bin2mix,
    mix2binf, binf2mix,
)

from .multistate_network import (
    MultistateFunction,
    MultistateNetwork,
)
from ._generate_multistate import (
    random_MSN
)

# Version
try:
    from ._version import __version__
except ImportError:
    __version__ = "unknown"

__all__ = [
    "bin2dec",
    "dec2bin",
    "get_left_side_of_truth_table",
    "hamming_weight_to_ncf_layer_structure",
    "get_shannon_entropy",
    "BooleanFunction",
    "display_truth_table",
    "get_layer_structure_from_canalized_outputs",
    "BooleanNetwork",
    "get_entropy_of_basin_size_distribution",
    "WiringDiagram",
    "random_function",
    "random_NCF",
    "random_k_canalizing_function",
    "random_wiring_diagram",
    "random_network",
    "random_null_model",
    "get_bio_models_from_repository",
    "__version__",
    
    "compress_trajectories",
    "product_of_trajectories",
    "plot_trajectory",

    "MultistateFunction",
    "MultistateNetwork",
    "random_MSN"
]